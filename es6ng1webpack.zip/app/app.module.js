import angular from 'angular';
import uiRouter from 'angular-ui-router';
import ngSanitize from 'angular-sanitize';
import uiBootstrap from 'angular-ui-bootstrap';

import 'bootstrap/dist/css/bootstrap.min.css';

import UserProfileService from './app.services';
import defineStates from './app.states';
import appComponent from './components/app/app.component';
import home from './components/home/home.component';
import aboutus from './components/aboutus/aboutus.component';

const MODULE_NAME = "webpackApp";

angular
    .module(MODULE_NAME,
        [
            uiRouter,
            ngSanitize,
            uiBootstrap
        ])
    .factory("UserProfileService", UserProfileService)
    .component("home", home)
    .component("aboutus", aboutus)
    .component("mainApp", appComponent)
    .config(defineStates)
    .run(() => {
        console.log("Application Initialized Successfully!");
    });

require('../index.html');

export default MODULE_NAME;
