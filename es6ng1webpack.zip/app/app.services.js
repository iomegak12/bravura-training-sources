const generateRandomId = () => {
    return Math.floor(
        Math.random() * (100000 - 1) + 1
    );
};

const UserProfileService = function () {
    return {
        getUserProfile: function () {
            return `USER-${generateRandomId()}`;
        }
    }
};

export default UserProfileService;