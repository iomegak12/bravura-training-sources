const aboutus = {
    bindings: {},
    templateUrl: require('./aboutus.component.html'),
    controller: function ($scope) {
        $scope.aboutUsTitle = 'Bravura Solutions';
    }
};

export default aboutus;