const home = {
    bindings: {},
    templateUrl: require('./home.component.html'),
    controller: function ($scope, UserProfileService) {
        var userName = UserProfileService.getUserProfile();

        $scope.welcomeMessage = `Welcome ${userName}`;
    }
};

export default home;