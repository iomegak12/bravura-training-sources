const appComponent = {
    bindings: {},
    templateUrl: require("./app.component.html"),
    controller: function ($scope) {
        $scope.message = "This application component is the main component of the application!";
    }
};

export default appComponent;
