const defineStates = ($stateProvider, $locationProvider, $urlRouterProvider) => {
    $urlRouterProvider.otherwise("/");
    $locationProvider.html5Mode(true);

    $stateProvider.state("home", {
        url: '/home',
        template: '<home></home>'
    });

    $stateProvider.state("aboutus", {
        url: '/about-us',
        template: '<aboutus></aboutus>'
    });
};

export default defineStates;