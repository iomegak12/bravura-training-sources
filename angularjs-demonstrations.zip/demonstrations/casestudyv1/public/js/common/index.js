var commonModule = angular.module("com.bravura.modules.common", 
    [
        'com.bravura.modules.common.config',
        'com.bravura.modules.common.directives',
        'com.bravura.modules.common.routes'
    ]);

commonModule.run(() => {
    console.log("Common Module Initialized Successfully!");
});