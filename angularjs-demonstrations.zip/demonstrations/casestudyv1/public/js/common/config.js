var commonConfigModule = angular.module("com.bravura.modules.common.config", []);

commonConfigModule.constant("viewPaths", {
    "header": "js/common/partials/header.html",
    "footer": "js/common/partials/footer.html"
});