var commonDirectivesModule = 
    angular.module("com.bravura.modules.common.directives", 
        [
            'com.bravura.modules.common.config'
        ]);

commonDirectivesModule
    .directive("globalHeader", ["viewPaths", function (viewPaths) {
        return {
            restrict: "E",
            templateUrl: viewPaths.header
        };
    }]);

    commonDirectivesModule
    .directive("globalFooter", ["viewPaths", function (viewPaths) {
        return {
            restrict: "E",
            templateUrl: viewPaths.footer
        };
    }]);