var routerModule = angular.module("com.bravura.modules.common.routes", ["ngRoute"]);

routerModule.config(["$routeProvider", function ($routeProvider) {
    $routeProvider
        .when("/home", {
            templateUrl: "js/common/partials/home.html"
        })
        .when("/about", {
            templateUrl: "js/common/partials/about.html"
        })
        .otherwise({
            redirectTo: "/home"
        });
}]);