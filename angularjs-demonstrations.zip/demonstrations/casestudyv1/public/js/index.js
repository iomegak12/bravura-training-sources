var mainModule = angular.module('com.bravura.casestudy',
    [
        "com.bravura.modules.common",
        "com.bravura.modules.phonecatalog"
    ]);

mainModule.run(() => {
    console.log("Case Study Module Initialized Successfully!");
});