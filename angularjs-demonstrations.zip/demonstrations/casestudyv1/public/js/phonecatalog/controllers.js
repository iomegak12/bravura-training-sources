var phoneCatalogControllersModule =
    angular.module("com.bravura.modules.phonecatalog.controllers",
        [
            "com.bravura.modules.phonecatalog.services"
        ]);

phoneCatalogControllersModule.controller("PhoneCatalogController",
    [
        "$scope",
        "phoneCatalogService",
        function ($scope, phoneCatalogService) {
            $scope.phones = [];

            phoneCatalogService.getPhones().then(function (response) {
                $scope.phones = response.data;
            });
        }
    ]);

phoneCatalogControllersModule.controller("PhoneDetailsController",
    [
        "$scope",
        "$routeParams",
        "phoneCatalogService",
        function ($scope, $routeParams, phoneCatalogService) {
            $scope.phone = {};

            phoneCatalogService.getPhoneDetail($routeParams.phoneId).then(
                function (response) {
                    $scope.phone = response.data;
                    $scope.mainImage = $scope.phone.images[0];
                });

            $scope.changeImage = function (image) {
                $scope.mainImage = image;
            };
        }
    ]);
