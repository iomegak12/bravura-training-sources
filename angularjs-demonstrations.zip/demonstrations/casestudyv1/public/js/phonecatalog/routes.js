var phoneCatalogRouterModule =
    angular.module("com.bravura.modules.phonecatalog.routes",
        [
            "ngRoute",
            "com.bravura.modules.phonecatalog.controllers",
            "com.bravura.modules.phonecatalog.directives"
        ]);

phoneCatalogRouterModule.config(["$routeProvider", function ($routeProvider) {
    $routeProvider
        .when("/phone-catalog", {
            templateUrl: "js/phonecatalog/partials/phonecatalog.html",
            controller: 'PhoneCatalogController'
        })
        .when("/phone-details/:phoneId", {
            templateUrl: "js/phonecatalog/partials/phonedetails.html",
            controller: 'PhoneDetailsController'
        });
}]);