var phoneCatalogFiltersModule =
    angular.module('com.bravura.modules.phonecatalog.filters', []);

phoneCatalogFiltersModule.filter('checkmark', function () {
    return function (input) {
        return input ? '\u2713' : '\u2718';
    };
});