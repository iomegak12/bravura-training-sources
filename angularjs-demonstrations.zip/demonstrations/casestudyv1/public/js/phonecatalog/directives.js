var phoneCatalogDirectivesModule =
    angular.module("com.bravura.modules.phonecatalog.directives",
        [
            "com.bravura.modules.phonecatalog.config"
        ]
    );

phoneCatalogDirectivesModule.directive("searchPanel",
    [
        "templateUrls",
        function (templateUrls) {
            return {
                restrict: 'E',
                templateUrl: templateUrls.searchPanelTemplateUrl,
            };
        }]);