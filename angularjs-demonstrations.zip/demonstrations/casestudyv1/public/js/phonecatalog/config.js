var phoneCatalogMoule = angular.module("com.bravura.modules.phonecatalog.config",
    [
    ]);

phoneCatalogMoule.constant("serviceUrls", {
    phoneCatalogBaseServiceUrl: "/phones/phones.json",
    phoneDetailBaseServiceUrl: "/phones"
});

phoneCatalogMoule.constant("templateUrls", {
    searchPanelTemplateUrl: "js/phonecatalog/partials/searchpanel.html"
});