var phoneCatalogModule =
    angular.module("com.bravura.modules.phonecatalog",
        [
            "com.bravura.modules.phonecatalog.config",
            "com.bravura.modules.phonecatalog.routes",
            "com.bravura.modules.phonecatalog.services",
            "com.bravura.modules.phonecatalog.controllers",
            "com.bravura.modules.phonecatalog.directives",
            "com.bravura.modules.phonecatalog.filters"
        ]
    );

phoneCatalogModule.run(() => {
    console.log("Phone Catalog Module Initialized Successfully!");
});