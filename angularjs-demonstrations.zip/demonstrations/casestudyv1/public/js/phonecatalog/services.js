var phoneCatalogServiceModule =
    angular.module("com.bravura.modules.phonecatalog.services", 
        [
            "com.bravura.modules.phonecatalog.config"
        ]);

phoneCatalogServiceModule.factory("phoneCatalogService", ["$http", "serviceUrls",
    function ($http, serviceUrls) {
        var phoneCatalogService = {};

        phoneCatalogService.getPhones = function () {
            return $http.get(serviceUrls.phoneCatalogBaseServiceUrl);
        };

        phoneCatalogService.getPhoneDetail = function (phoneId) {
            return $http.get(serviceUrls.phoneDetailBaseServiceUrl + "/" + phoneId + ".json");
        };

        return phoneCatalogService;
    }]);