angular.module("professionalApp", ['ngRoute'])
    .constant("viewUrls", {
        "header": "./partials/header.html",
        "footer": "./partials/footer.html"
    })
    .directive("globalHeader", ['viewUrls', function (viewUrls) {
        return {
            restrict: "EA",
            templateUrl: viewUrls.header,
            controller: 'HeaderController'
        };
    }])
    .directive("globalFooter", ['viewUrls', function (viewUrls) {
        return {
            restrict: "EA",
            templateUrl: viewUrls.footer
        };
    }])
    .directive("globalNavigation", ['viewUrls', function (viewUrls) {
        return {
            restrict: "EA",
            templateUrl: "./partials/navigation.html"
        };
    }])
    .controller('HeaderController', function ($scope) {
        $scope.companyName = "Bravura Solutions";
    })
    .config(function ($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: 'partials/home.html'
            })
            .when('/about', {
                templateUrl: 'partials/about.html'
            })
            .when('/contact', {
                templateUrl: 'partials/contact.html'
            })
            .otherwise({
                redirectTo: '/'
            });
    });