/**
 * Created by Ramkumar on 12/22/2016.
 */

function getData(callback) {
    setTimeout(()=> {
        if (typeof callback === 'function') {
            callback(100);
        }
    }, 5000);
}

function getDataFromRemoteSite(callback) {
    setTimeout(()=> {
        if (typeof callback === 'function') {
            callback(200);
        }
    }, 7000);
}

getData((data)=>console.log('Data Received ... ' + data));
getDataFromRemoteSite(
    (data)=>console.log('Data Received from Remote Site ... ' + data));
