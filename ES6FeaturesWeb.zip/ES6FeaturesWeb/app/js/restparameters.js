/**
 * Created by Ramkumar on 12/22/2016.
 */
function process(inputA, inputB) {
    console.log(inputA + ', ' + inputB);
    console.log(arguments);
}

function modernProcess(inputA, inputB, ...args) {
    console.log(inputA + ', ' + inputB);
    console.log(args);
    console.log(args[args.length - 1]);
}

process(10, 20, 30, 40, 50);
modernProcess(10, 20, 30, 40, 50);