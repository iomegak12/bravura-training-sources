/**
 * Created by Ramkumar on 12/22/2016.
 */

const i = 100;
const status = true;

function process() {
    // i++; // throws an error

    console.log(i);
}

console.log(i);