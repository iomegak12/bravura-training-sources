/**
 * Created by Ramkumar on 12/22/2016.
 */

function* getValues() {
    console.log('Started ...');

    console.log('Operation 1 ...');
    yield 10;

    console.log('Operation 2 ...');
    yield 20;

    console.log('Operation 3 ...');
    yield 30;
}

var generator = getValues();

console.log(generator.next());
console.log(generator.next());
console.log(generator.next());
console.log(generator.next());

var generator2 = getValues();

for (var value of generator2) {
    console.log(value);

    if (value >= 20)
        break;
}

console.log('End of Program!');