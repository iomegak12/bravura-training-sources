/**
 * Created by Ramkumar on 12/22/2016.
 */

class Customer {
    constructor(...args) {
        [this.id, this.name, this.address, this.credit, this.status] = args;
    }

    format() {
        return `${this.id}, ${this.name}, 
            ${this.address}, ${this.credit}, ${this.status}`;
    }
}

var customer = new Customer(10, 'Sachin', 'Bangalore', 12000, true);

console.log(customer.format());