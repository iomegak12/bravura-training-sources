/**
 * Created by Ramkumar on 12/22/2016.
 */

function process() {
    let x = 10;
    let output = 0;

    for (let i = 0; i <= x; i++) {
        output += i;
    }

    console.log('Value of x is : ' + x);
    console.log('Value of output is : ' + output);
    console.log('Value of i is : ' + i); // throw error in ES6
}

process();