/**
 * Created by Ramkumar on 12/22/2016.
 */

Array.prototype.isExist =
    function (item) {
        var status = false;

        for (var index in this) {
            if (this[index] === item) {
                status = true;
                break;
            }
        }

        return status;
    };

Array.prototype.isExist2 =
    function (item) {
        var existLogic = (values) => {
            var status = false;

            for (var index in values) {
                if (this[index] === item) {
                    status = true;
                    break;
                }
            }

            return status;
        };

        return existLogic(this);
    };

console.log(['Siddhardh', 'Velu', 'Srinivas'].isExist('Rajesh'));
console.log(['Siddhardh', 'Velu', 'Srinivas', 'Devi'].isExist2('Devi'));