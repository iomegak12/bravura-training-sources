/**
 * Created by Ramkumar on 12/22/2016.
 */

function processOrder(order) {
    console.log('Order Processing Started ...');
    console.log(order.orderId + ', ' +
        order.orderDate + ', ' + order.amount);
    console.log('Order Processing Completed ...');
}

Array.prototype.isExist = function (item) {
    var status = false;

    for (var index in this) {
        if (this[index] === item) {
            status = true;
            break;
        }
    }

    return status;
};

var processOrder = new Proxy(processOrder, {
    apply: function (target, current, args) {
        var processedOrders = ['ORD10001','ORD10002','ORD10003'];

        console.log('Deciding whether to call original service ...');

        var order = args[0];

        if(!processedOrders.isExist(order.orderId)) {
            console.log('Order has NOT been processed yet ... invoking the original functionality ...');
            target(...args);
        }
        else {
            console.log('Order has been already processed ... returning cached output!');
        }
    }
});

processOrder({
    orderId: 'ORD100010',
    orderDate: new Date(),
    amount: 12000
});

processOrder({
    orderId: 'ORD10001',
    orderDate: new Date(),
    amount: 12000
});


