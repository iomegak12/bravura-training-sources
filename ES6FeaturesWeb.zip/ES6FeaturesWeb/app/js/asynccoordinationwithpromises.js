/**
 * Created by Ramkumar on 12/22/2016.
 */

const DEFAULT_TIME_OUT = 5000;
const COMPLEX_DEFAULT_TIME_OUT = 8000;

function getData() {
    var promise = new Promise(
        function (success, reject) {
            setTimeout(()=> {
                success(100);
            }, DEFAULT_TIME_OUT);
        });

    return promise;
}

function getDataFromRemoteSite(input) {
    var promise = new Promise(
        function (success, reject) {
            setTimeout(
                ()=> {
                    if (input >= 200)
                        success(200);
                    else reject(false);
                }, COMPLEX_DEFAULT_TIME_OUT);
        });

    return promise;
}

Promise.all([getData(), getDataFromRemoteSite(300)])
    .then(
        function (results) {
            console.log('Both Promises Successfully Resolved ... ' +
                JSON.stringify(results));
        },
        function (error) {
            console.log('One of the promises Failed ... ' +
                JSON.stringify(error));
        });