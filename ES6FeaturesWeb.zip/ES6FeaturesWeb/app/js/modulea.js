/**
 * Created by Ramkumar on 12/22/2016.
 */

class A {
    constructor(id, name) {
        this.id = id;
        this.name = name;
    }

    format() {
        return this.id + ', ' + this.name;
    }
}

export function process(...args) {
    var a = new A(...args);

    return a.format();
}

export default function() {
    return 10;
}