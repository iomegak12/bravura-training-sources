/**
 * Created by Ramkumar on 12/22/2016.
 */

var obj = {
    doProcess: ()=>10,
    doProcess2: ()=>20
};

export default obj;