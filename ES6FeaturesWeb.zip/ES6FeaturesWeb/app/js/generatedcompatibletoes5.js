/**
 * Created by Ramkumar on 12/22/2016.
 */

function Iterator(...args) {
    var totalItems = args.length;
    var index = 0;

    return function () {
        var itemsToPush = [];
        var noOfTimesToLoop = 0;

        for (; index < totalItems; index++) {
            itemsToPush.push(args[index]);

            if (++noOfTimesToLoop >= 2) {
                return itemsToPush;
            }
        }
    };
}

var generator = Iterator(10, 20, 30, 40, 50);

console.log(generator());
console.log(generator());
console.log(generator());