/**
 * Created by Ramkumar on 12/22/2016.
 */

var obj = {
    id: 10,
    name: 'Nagesh',
    address: {
        line1: 'Last Row',
        line2: 'First Column'
    }
};

function process({name: studentName = 'Default', address: {line1: addressLine1}}) {

    console.log(studentName + ', ' + addressLine1);

}

process(obj);

var [a, b, c, d = 10] = (()=>[10, 20, 30])();

// Self Invoking Functions
(function(a, b) {
    }
)(10, 20);