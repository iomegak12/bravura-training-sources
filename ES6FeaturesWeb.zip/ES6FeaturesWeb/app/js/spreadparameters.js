/**
 * Created by Ramkumar on 12/22/2016.
 */

function process(inputA, inputB, inputC, inputD, inputE, ...args) {
    console.log(inputA + ', ' +
        inputB + ', ' + inputC + ', ' + inputD + ', ' + inputE);

    console.log(args);
}

var values = [10, 20, 30, 40, 50, 60, 70, 80];

process(...values);
process(...[10]);