/**
 * Created by Ramkumar on 12/22/2016.
 */

function process() {
    this.id = 10;
    this.name = 'Reference';

    this.doWork = function () {
        console.log(this.id + ', ' + this.name);
    };
}

process.prototype.doWork2 = function () {
    var self = this;

    return function () {
        return self.id + ', ' + self.name;
    };
};

var p = new process();

p.doWork();
console.log(p.doWork2()());
