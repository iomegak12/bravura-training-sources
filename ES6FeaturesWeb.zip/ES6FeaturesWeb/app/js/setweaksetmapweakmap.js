/**
 * Created by Ramkumar on 12/22/2016.
 */

var set = new Set([10, 20, 30, 40, 50]);

console.log(set.keys());
console.log(set.values());

for (var item of set) {
    console.log(item);
}

set.forEach(item=>console.log(item));

console.log(set.has(20));
console.log(set.has(100));

var weakSet = new WeakSet();

var obj1 = {};
var obj2 = function () {
    return 10;
}
var obj3 = {id: 10};

weakSet.add(obj1);
weakSet.add(obj2);
weakSet.add(obj3);

console.log(weakSet.has(obj2));

obj2 = null;

console.log(weakSet.has(obj2));

var map = new Map();

map.set(10, 'Nagesh');
map.set(11, 'Sachin');
map.set(12, 'Srinivas');

console.log(map.has(10));
console.log(map.get(11));

for (var item of map.keys())
    console.log(map.get(item));

map.delete(11);

console.log(map.size);

var weakMap = new WeakMap();
var objX = {};
var objY = {};
var objZ = {};

weakMap.set(objX, 'X Property');
weakMap.set(objY, 'Y Property');
weakMap.set(objZ, 'Z Property');

objY = null;

console.log(weakMap.has(objY));
console.log(weakMap[objY]);