/**
 * Created by Ramkumar on 12/22/2016.
 */

class Customer {
    constructor(id, name, address, credit, status) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.credit = credit;
        this.status = status;
    }

    get ReferenceKey() {
        return this.referenceKey;
    }

    set ReferenceKey(value) {
        this.referenceKey = value;
    }

    format() {
        return this.id + ', ' + this.name + ', ' +
            this.address + ', ' + this.credit + ', ' + this.status;
    }
}

let customer = new Customer(10, 'Northwind', 'Bangalore', 12000, true);

customer.ReferenceKey = 23000;

console.log(customer.format() + ', ' + customer.ReferenceKey);