/**
 * Created by Ramkumar on 12/22/2016.
 */

var obj = {
    id: 10,
    name: 'Northwind Traders',
    address: 'Bangalore',
    credit: 23000,
    status: true,
    orders: ['ORD10001', 'ORD10002', 'ORD10003', 'ORD10004', 'ORD10005'],
    [Symbol.iterator]: function*() {
        for (var index in this.orders) {
            var order = this.orders[index];

            if (order) {
                yield order;
            }
        }
    }
};

for (var property in obj) {
    console.log(property + ', ' + obj[property]);
}

for(var value of obj) {
    console.log(value);
}