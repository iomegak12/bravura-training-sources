/**
 * Created by Ramkumar on 12/22/2016.
 */

var currentId = 173;
var octalCurrentId = 0o255;

console.log(currentId == octalCurrentId);

var binaryCurrentId = 0b10101101;
console.log(currentId == binaryCurrentId);
console.log(typeof binaryCurrentId);
console.log(typeof octalCurrentId);