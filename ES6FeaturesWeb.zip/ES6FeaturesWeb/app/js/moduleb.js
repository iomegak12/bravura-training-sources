/**
 * Created by Ramkumar on 12/22/2016.
 */

import {process} from 'js/modulea.js';
console.log(process(10, 'Rajesh', 'Chennai'));

import * as ModuleA from 'js/modulea.js';
console.log(ModuleA.process(10, 'Sachin', 'Third Row'));

import ln from 'js/modulea.js';
console.log(ln());