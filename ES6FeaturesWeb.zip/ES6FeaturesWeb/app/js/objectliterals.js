/**
 * Created by Ramkumar on 12/22/2016.
 */

var id = 10;
var name = 'Savithri';
var location = 'Third Row 2nd Column';
var getId = function () {
    return 32;
};

var student = {
    id,
    name,
    location,
    format() {
        return this.id + ', ' + this.name + ', ' + this.location
    },
    ['_identifier' + getId()]: ()=> 10,
    ['_property' + getId()]: 200
};

class Student {
    constructor(...args) {
        [this.id, this.name, this.location] = args;
    }

    doWork() {
        console.log('Student is Studying Now ... ' + this.name);
    }
}

student.__proto__ = new Student();

console.log(student.format());
console.log(student._identifier32());
console.log(student._property32);

console.log(typeof student);
console.log(student instanceof  Student);

student.doWork();