/**
 * Created by Ramkumar on 12/22/2016.
 */

const SEPARATOR = ',';

class Customer {
    constructor(id, name, address, credit, status) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.credit = credit;
        this.status = status;
    }

    static createInstance(csvString) {
        var splittedString = csvString.split(SEPARATOR);

        return new Customer(...splittedString);
    }
}

var csvString = '10,Rajesh,Chennai,12000,true';
var customer = Customer.createInstance(csvString);

console.log(customer.id + ', ' + customer.name);