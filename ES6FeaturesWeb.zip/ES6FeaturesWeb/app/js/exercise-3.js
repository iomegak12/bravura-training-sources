/**
 * Created by Ramkumar on 12/22/2016.
 */

function* processValues(...args) {
    var totalNoOfItems = args.length;
    var itemsToReturn = [];

    for (var index in args) {
        itemsToReturn.push(args[index]);

        if (index % 2 == 1) {
            yield itemsToReturn;

            itemsToReturn = [];
        }
    }
}

var generator = processValues(10, 20, 30, 40, 50, 60);

for (var valueSet of generator) {
    console.log(valueSet);
}