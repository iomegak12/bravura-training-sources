/**
 * Created by Ramkumar on 12/22/2016.
 */
class Customer {
    constructor(id, name, address, credit, status) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.credit = credit;
        this.status = status;
    }

    format() {
        var message = '';

        for (var property in this) {
            if (typeof this[property] !== 'function') {
                message += this[property] + ', ';
            }
        }

        return message;
    }
}

class InternetCustomer extends Customer {
    constructor(id, name, address, credit, status, blogUrl) {
        super(...arguments);

        this.blogUrl = blogUrl;
    }

    format() {
        return super.format().toUpperCase();
    }
}

var customer = new Customer(10, 'Mahesh', 'New Delhi', 12000, true);
console.log(customer.format());

var internetCustomer = new InternetCustomer(
    10, 'Mahesh', 'New Delhi', 12000, true, 'http://blogs.msdn.com/mahesh');

console.log(internetCustomer.format());