/**
 * Created by Ramkumar on 12/22/2016.
 */

import utils from 'js/advancedmodule.js';

console.log(utils.doProcess());
console.log(utils.doProcess2());