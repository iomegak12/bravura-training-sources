/**
 * Created by Ramkumar on 12/22/2016.
 */

function generateRandom(minimum = 1, maximum = 100) {
    var generatedRandomNumber =
        Math.floor(Math.random() * (maximum - minimum) + minimum);

    return generatedRandomNumber;
}

function process(x = generateRandom(), y = generateRandom(x, 100)) {
    console.log(x + ', ' + y);
}

process(100, 100);
process();
process(90);
process(100);
