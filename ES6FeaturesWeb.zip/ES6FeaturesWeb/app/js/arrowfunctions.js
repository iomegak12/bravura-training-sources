/**
 * Created by Ramkumar on 12/22/2016.
 */

const MIN_ORDER_AMOUNT = 1000;

function process(id, amount, callback) {
    console.log(id + ', ' + amount);

    let status = id && amount && amount >= MIN_ORDER_AMOUNT;

    if (typeof callback === 'function') {
        callback(status);
    }
}

process(10, 9000,
    function (status) {
        console.log('Callback Called ... ' + status);
    });

process(10, 9000, s => console.log(s));
process(10, 9000, s => {
    console.log('Callback Called (Arrow Functions) ... ' + s);
});