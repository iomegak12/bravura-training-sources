/**
 * Created by Ramkumar on 12/22/2016.
 */

function process() {
    var callbacks = arguments;
    var output = 0;

    for (var index in callbacks) {
        var callback = callbacks[index];

        if (typeof callback === 'function') {
            output += callback(10, 10);
        }
    }

    console.log('Output : ' + output);
}

process(
    (a, b)=>a + b,
    (a, b)=> {
        console.log('Good to go!');
        return a - b
    },
    (a, b)=>a * b,
    (a, b)=>a / b);