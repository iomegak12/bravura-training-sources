/**
 * Created by Ramkumar on 12/22/2016.
 */
function execute(param1) {
    let output = param1(10, 20);
    
    return (a, b) => a + b + output;
}

var resultCallback = execute((x, y) => x * y);

console.log(resultCallback(100, 100));