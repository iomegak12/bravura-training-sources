import { Link } from "react-router-dom";

const Navigation = (props: any) => {
    return (
        <>
            {
                props.isHome &&

                <div>
                    <Link to="/about-us">About Us</Link>
                    |
                    <Link to="/contact">Contact</Link>
                </div>
            }

            {
                props.isAboutUs &&

                <div>
                    <Link to="/">Home</Link>
                    |
                    <Link to="/contact">Contact</Link>
                </div>
            }


            {
                props.isContact &&

                <div>
                    <Link to="/">Home</Link>
                    |
                    <Link to="/about-us">About Us</Link>
                </div>
            }
        </>
    );
};

export default Navigation;