import Navigation from "./Navigation";

const AboutUs = () => {
    return (
        <>
            <h3>About the Company</h3>

            <br />

            <Navigation isAboutUs={true} />
        </>
    );
};

export default AboutUs;