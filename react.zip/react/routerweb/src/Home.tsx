import Navigation from "./Navigation";

const Home = () => {
    return (
        <>
            <h3>Welcome Home!</h3>

            <br />

            <Navigation isHome={true} />
        </>
    );
};

export default Home;