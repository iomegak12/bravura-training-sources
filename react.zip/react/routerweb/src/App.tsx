import { Route, Routes } from "react-router-dom";
import Home from "./Home";
import AboutUs from "./AboutUs";
import Contact from "./Contact";

const App = () => {
    return (
        <>
            <h1>Welcome to React Router</h1>
            <h2>Happy to welcome to the world of React Routing!</h2>

            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about-us" element={<AboutUs />} />
                <Route path="/contact" element={<Contact />} />
            </Routes>
        </>
    );
};

export default App;