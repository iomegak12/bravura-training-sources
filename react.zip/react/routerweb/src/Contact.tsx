import Navigation from "./Navigation";

const Contact = () => {
    return (
        <>
            <h3>React Us Out!!!</h3>

            <br />

            <Navigation isContact={true} />
        </>
    );
};

export default Contact;