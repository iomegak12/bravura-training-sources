Progressus - Free business/corporate Bootstrap template
=============

Progressus is a free, responsive, nice-looking business template based on Bootstrap HTML/CSS framework. 


License
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/


Features
-----------

* Easy to use, fat-free HTML and CSS code.
* 7 ready-made templates for most common tasks
* Responsive design
* High overral quality, the template does worth to be premium.


Bug tracker
-----------

Found a bug? Please create an issue here on GitHub! 
https://github.com/pozh/Progressus/issues


Credits
-------
* Design and development: **Sergey Pozhilov** - http://pozhilov.com
* Photos used in template: **Unsplash** - http://unsplash.com
* More free templates by Sergey: http://gettemplate.com
