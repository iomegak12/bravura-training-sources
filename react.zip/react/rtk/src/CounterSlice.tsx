import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initialState = {
    counter: 0
};

const CounterSlice = createSlice({
    name: "Counter",
    reducers: {
        increment: (state: any, action: PayloadAction<number>) => {
            state.counter = state.counter + action.payload;
        },
        decrement: (state: any, action: PayloadAction<number>) => {
            state.counter = parseInt(state.counter) - action.payload;
        },
        reset: (state: any, action: PayloadAction<number>) => {
            state.counter = action.payload;
        }
    },
    initialState: initialState
});

const CounterActions = CounterSlice.actions;

export {
    CounterActions
};

export default CounterSlice;