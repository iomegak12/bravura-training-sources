import { configureStore } from "@reduxjs/toolkit";
import CounterSlice from "./CounterSlice";

const store = configureStore({
    reducer: {
        counterState: CounterSlice.reducer
    }
});

// To enable typescript to understand Root State Structure and Dispatcher Structure

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch

export default store;