import { useSelector } from "react-redux";
import { AppDispatch, RootState } from "./Store";
import { useDispatch } from "react-redux";
import { CounterActions } from "./CounterSlice";

const CounterComponent = () => {
    const counterState = useSelector((state: RootState) => state.counterState);
    const dispatcher: AppDispatch = useDispatch();

    return (
        <>
            <h1>Counter Component</h1>
            <div>
                CURRENT COUNTER: {counterState.counter}
            </div>

            <br />

            <button onClick={() => dispatcher(CounterActions.increment(10))}>
                Increment
            </button>
            &nbsp; | &nbsp;
            <button onClick={() => dispatcher(CounterActions.decrement(10))}>
                Decrement
            </button>
            &nbsp; | &nbsp;
            <button onClick={() => dispatcher(CounterActions.reset(10))}>
                Reset
            </button>
        </>
    )
};

export default CounterComponent;