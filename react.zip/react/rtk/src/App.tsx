import { Provider } from "react-redux";
import store from "./Store";
import CounterComponent from "./CounterComponent";
import CounterView from "./CounterViewComponent";

const App = () => {
    return (
        <>
            <Provider store={store}>
                <CounterComponent />

                <br/>
                <br/>

                <CounterView />
            </Provider>
        </>
    );
};

export default App;