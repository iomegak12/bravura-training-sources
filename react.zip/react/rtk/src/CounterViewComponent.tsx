import { useSelector } from "react-redux";
import { RootState } from "./Store";

const CounterView = () => {
    const counterState = useSelector((state: RootState) => state.counterState);

    return (
        <>
            <b>
                COUNTER VIEW :
                {counterState.counter}
            </b>
        </>
    );
};

export default CounterView;