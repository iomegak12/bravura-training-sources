import { useReducer } from "react";
import useInterval from "./CustomHooks";

const combinedReducers = (state: any, payload: any) => {
    if (payload.type === "INCREMENT") {
        return state + 1;
    }

    if (payload.type === "DECREMENT") {
        return state - 1;
    }

    if (payload.type === "RESET") {
        return 0;
    }
};

const DEFAULT_INTERVAL = 5000;

const CounterComponent = () => {
    const [currentState, dispatcher] = useReducer(combinedReducers, 0);

    const execute = (type: string) => {
        dispatcher({
            type
        });
    };

    useInterval(() => {
        execute("INCREMENT");
    }, DEFAULT_INTERVAL);

    return (
        <>
            <h1>Understanding Redux using Hooks</h1>
            <h2>CURRENT COUNT: {currentState}</h2>

            <button onClick={() => execute("INCREMENT")}>Increment</button> &nbsp;
            <button onClick={() => execute("DECREMENT")}>Decrement</button> &nbsp;
            <button onClick={() => execute("RESET")}>Reset</button>
        </>
    );
};

export default CounterComponent;