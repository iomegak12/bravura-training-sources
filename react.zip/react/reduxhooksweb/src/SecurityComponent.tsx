import { createContext, useContext, useRef, useState } from "react";

type SecurityContextType = {
    userName: string,
    setUserName: (un: string) => void
}

const defaultValue: SecurityContextType = {
    userName: "",
    setUserName: (name: string) => { }
}

const SecurityContext = createContext<SecurityContextType>(defaultValue);

const LoginComponent = () => {
    const { setUserName } = useContext(SecurityContext);
    const textRef = useRef<HTMLInputElement>(null);

    const login = () => {
        // AUTHENTICATION LOGIC

        let currentUserName = textRef?.current?.value;

        if (currentUserName?.startsWith("bravura")) {
            setUserName(currentUserName);
        }
    };

    return (
        <>
            <input type="text" ref={textRef} placeholder="Enter Login Name" />

            &nbsp;

            <button onClick={login}>Login</button>
        </>
    );
};

const ProfileComponent = () => {
    const { userName, setUserName } = useContext(SecurityContext);

    const logout = () => {
        setUserName("");
    };

    return (
        <>
            LOGGED IN USER : {userName}

            <button onClick={logout}>Logout</button>
        </>
    );
};

const SecurityComponent = () => {
    const [loggedInUser, setLoggedInUser] = useState("");

    return (
        <>
            <SecurityContext.Provider value={{ userName: loggedInUser, setUserName: setLoggedInUser }}>
                {
                    !loggedInUser &&
                    (
                        <LoginComponent />
                    )
                }

                {
                    loggedInUser &&
                    (
                        <ProfileComponent />
                    )
                }
            </SecurityContext.Provider>
        </>
    )
};

export default SecurityComponent;