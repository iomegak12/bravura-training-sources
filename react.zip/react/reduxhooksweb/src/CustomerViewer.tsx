import { useReducer, useState } from "react";

class Customer {
    constructor(public id: number, public name: string, public email: string, public age: number) { }
}

class CustomerService {
    getCustomers() {
        return [
            new Customer(11, "Northwind Traders", "info@nwt.com", 56),
            new Customer(12, "Southwind Traders", "info@nwt.com", 50),
            new Customer(13, "Eastwind Traders", "info@nwt.com", 49),
            new Customer(14, "Westwind Traders", "info@nwt.com", 63),
            new Customer(15, "Adventureworks", "info@nwt.com", 67),
            new Customer(16, "Footmart", "info@nwt.com", 40)
        ];
    }
}

const reducers = (state: any, action: any) => {
    let newState = state;

    if (action.type === "LOAD") {
        const customerService = new CustomerService();

        newState = customerService.getCustomers();
    }

    if (action.type === "FILTER") {
        const ageFilterValue = action.payload;

        newState = state.filter((element: Customer) => element.age >= ageFilterValue);
    }

    return newState;
};


const CustomersViewer = () => {
    const [customers, dispatcher] = useReducer(reducers, []);
    const [age, setAge] = useState(40);

    const executeAction = (actionString: any, payload?: any) => {
        const action = {
            type: actionString,
            payload
        };

        dispatcher(action);
    };

    return (
        <>
            <h1>Customers Viewer</h1>

            <button onClick={() => executeAction("LOAD")}>Load</button>
            &nbsp;
            <input type="text"
                value={age}
                onChange={(e) => setAge(parseInt(e.target.value))}
                placeholder="Enter Age to Filter Customer Records" />

            <button onClick={() => executeAction("FILTER", age)}>Filter</button>

            {
                customers &&

                (
                    <table>
                        <thead>
                            <tr>
                                <th>Customer #</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Age</th>
                            </tr>
                        </thead>

                        <tbody>
                            {
                                customers.map((record: Customer) => {
                                    return (
                                        <tr key={record.id}>
                                            <td>{record.id}</td>
                                            <td>{record.name}</td>
                                            <td>{record.email}</td>
                                            <td>{record.age}</td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                )
            }
        </>
    );
};

export default CustomersViewer;