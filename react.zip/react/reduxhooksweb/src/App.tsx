// import CounterComponent from "./CounterComponent";
// import CustomersViewer from "./CustomerViewer";

import SecurityComponent from "./SecurityComponent";

const App = () => {
    return (
        <>
            {/* <CounterComponent /> */}

            {/* <CustomersViewer /> */}

            <SecurityComponent />
        </>
    );
};

export default App;