export default class Customer {
    constructor(public id: number, public name: string,
        public email: string, public phone: string,
        public address: string) { }

    toString(): string {
        return `Customer[${this.id},${this.name},${this.email},${this.phone},${this.address}]`;
    }
}