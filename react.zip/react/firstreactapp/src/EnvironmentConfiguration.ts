class EnvironmentConfiguration {
    static getCustomerServiceUrl(): string | undefined {
        let serviceUrl: string | undefined = "";

        if (process.env.NODE_ENV === 'development') {
            serviceUrl = process.env.REACT_APP_CUSTOMER_SERVICE_URL;
        } else {
            serviceUrl = process.env.REACT_APP_CUSTOMER_SERVICE_URL;;
        }

        return serviceUrl;
    }
}

export default EnvironmentConfiguration;