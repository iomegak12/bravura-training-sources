import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import EnvironmentConfiguration from './EnvironmentConfiguration';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

const customerServiceUrl = EnvironmentConfiguration.getCustomerServiceUrl();

console.log(`Customer service URL: ${customerServiceUrl}`);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

