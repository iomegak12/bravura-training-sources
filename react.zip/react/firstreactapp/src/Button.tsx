import { useState } from "react";
import './Button.css';

const Button = (props: any) => {
    const [theme, setTheme] = useState(true);

    const toggleDarkTheme = () => {
        setTheme(!theme);
    };

    return (
        <>
            <div>
                <button onClick={toggleDarkTheme}>
                    Toggle dark theme
                </button>

                <div className={theme ? "light-mode" : "dark-mode"}>
                    {props.text}
                </div>
            </div>
        </>
    )
};

export default Button;