import Banner from "./Banner"

const App = () => {
    return (
        <>
            <Banner bannerTitle="Welcome to the World of React!" />
        </>
    )
};

export default App;