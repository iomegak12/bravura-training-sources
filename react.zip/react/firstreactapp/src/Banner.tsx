import Button from "./Button";
import { CustomersViewer } from "./CustomersViewer";

const Banner = (props: any) => {
    return (
        <div>
            <h1>
                {props.bannerTitle}
            </h1>

            <div>
                <Button text="Understanding How useState works!!!" />
            </div>

            <br/>

            <CustomersViewer />
        </div>
    );
};

export default Banner;