    import { useEffect, useState } from "react";
    import Customer from "./Customer";
    import CustomerService from "./CustomerService";

    export const CustomersViewer = () => {
        let fetchedCustomers: Customer[] = [];

        const [loading, setLoading] = useState(true);
        const [error, setError] = useState("");
        const [customers, setCustomers] = useState(fetchedCustomers);

        useEffect(() => {
            CustomerService.getCustomers()
                .then(customerRecords => {
                    setCustomers(customerRecords);
                    setLoading(false);
                })
                .catch(error => {
                    setLoading(false);
                    setError(error);
                });
        }, []);

        if (loading) {
            return (
                <>
                    <div>
                        Loading ...
                    </div>
                </>
            )
        }

        if (error) {
            return (
                <>
                    <div>
                        Error Occurred, Details : {error}
                    </div>
                </>
            )
        }


        return (
            <>
                <h1>Customers Information</h1>
                <ul>
                    {
                        customers.map((c: Customer) =>
                            <li key={c.id}>
                                {c.toString()}
                            </li>
                        )
                    }
                </ul>
            </>
        );
    };
