import Customer from "./Customer";
import EnvironmentConfiguration from "./EnvironmentConfiguration";

export default class CustomerService {
    static getCustomers(): Promise<Customer[]> {
        let customerServiceUrl: string | undefined =
            EnvironmentConfiguration.getCustomerServiceUrl();

        if (customerServiceUrl !== undefined) {
            return fetch(customerServiceUrl)
                .then(response => response.json())
                .then(data => data.map((c: any) =>
                    new Customer(c.id, c.name, c.email, c.phone, c.address)));
        } else {
            return Promise.reject("Customer Service URL is not defined");
        }
    }
}