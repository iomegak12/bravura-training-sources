import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import Layout from './components/Layout';
import { Provider } from 'react-redux';
import store from './store/store';
import EnvironmentConfiguration from './config/EnvironmentConfiguration';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

console.log(`Environment Service URL: ${EnvironmentConfiguration.getBaseServiceUrl()}`);

root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Provider store={store}>
        <Layout />
      </Provider>
    </BrowserRouter>
  </React.StrictMode>
);

