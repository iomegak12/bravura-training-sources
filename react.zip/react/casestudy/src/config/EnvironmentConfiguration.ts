class EnvironmentConfiguration {
    static getBaseServiceUrl() {
        if (process.env.NODE_ENV === "development") {
            return process.env.REACT_APP_CRM_BASE_URL;
        } else if (process.env.NODE_ENV === "production") {
            return process.env.REACT_APP_CRM_BASE_URL;
        }

        throw new Error("Invalid Configuration Key Specified!");
    }
}

export default EnvironmentConfiguration;