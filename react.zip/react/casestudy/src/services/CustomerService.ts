import EnvironmentConfiguration from "../config/EnvironmentConfiguration";
import Customer from "../models/Customer";
import ICustomerService from "./ICustomerService";

class CustomerService implements ICustomerService {
    private customerServiceUrl: string;

    constructor() {
        const customerServiceBaseUrl = EnvironmentConfiguration.getBaseServiceUrl();

        this.customerServiceUrl = `${customerServiceBaseUrl}/customers`;
    }

    async getCustomers(): Promise<Customer[]> {
        const result: any = await fetch(this.customerServiceUrl);
        const parsedResult = await result?.json();

        const customerRecords = parsedResult.map((element: any) => {
            const customer = new Customer(element.id,
                element.customerName, element.address,
                element.email, element.credit, element.activeStatus,
                element.summary, element.photoUrl);

            return customer;
        });

        return customerRecords;
    }

    async getCustomerById(id: number): Promise<Customer> {
        const url = `${this.customerServiceUrl}/${id}`;
        const result: any = (await fetch(url)).json();

        const customerRecord = new Customer(result.id,
            result.customerName, result.address,
            result.email, result.credit, result.activeStatus,
            result.summary, result.photoUrl);

        return customerRecord;
    }

}

export default CustomerService;