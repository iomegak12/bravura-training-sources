import Customer from "../models/Customer";

interface ICustomerService {
    getCustomers(): Promise<Customer[]>;
    getCustomerById(id: number): Promise<Customer>;
}

export default ICustomerService;