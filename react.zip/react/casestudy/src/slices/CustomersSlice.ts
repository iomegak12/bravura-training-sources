import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import Customer from "../models/Customer";

const initialState = {
    customers: [],
    isLoading: false,
    error: ""
};

const CustomersSlice = createSlice({
    name: "CustomersSlice",
    reducers: {
        loadCustomers: (state: any, action: PayloadAction<Customer[]>) => {
            state.customers = action.payload;
            state.isLoading = false;
            state.error = "";
        },
        loadCustomersSuccess: (state: any, action: PayloadAction) => {
            state.isLoading = false;
            state.error = "";
        },
        loadCustomersFailed: (state: any, action: PayloadAction<string>) => {
            state.isLoading = false;
            state.error = action.payload;
        }
    },
    initialState
});

const CustomersActions = CustomersSlice.actions;
const CustomersReducer = CustomersSlice.reducer;

export {
    CustomersActions,
    CustomersReducer
};

