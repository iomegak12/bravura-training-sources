const ContactUsForm = () => {
    return (
        <>
            <form>
                <div className="row">
                    <div className="col-sm-4">
                        <input className="form-control" type="text" placeholder="Name" />
                    </div>
                    <div className="col-sm-4">
                        <input className="form-control" type="text" placeholder="Email" />
                    </div>
                    <div className="col-sm-4">
                        <input className="form-control" type="text" placeholder="Phone" />
                    </div>
                </div>
                
                <br />

                <div className="row">
                    <div className="col-sm-12">
                        <textarea placeholder="Type your message here..." className="form-control" rows={9}></textarea>
                    </div>
                </div>
                <br />
                <div className="row">
                    <div className="col-sm-6">
                        <label className="checkbox"><input type="checkbox" /> Sign up for newsletter</label>
                    </div>
                    <div className="col-sm-6 text-right">
                        <input className="btn btn-action" type="submit" value="Send message" />
                    </div>
                </div>
            </form>
        </>
    );
};

export default ContactUsForm;