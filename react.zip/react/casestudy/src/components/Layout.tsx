import { BrowserRouter, Route, Routes } from "react-router-dom";
import GlobalHeader from "./GlobalHeader";
import GlobalFooter from "./GlobalFooter";
import Home from "./Home";
import AboutUs from "./AboutUs";
import ContactUs from "./ContactUs";
import SignInUp from "./SignInUp";
import Customers from "./Customers";

const Layout = () => {
    return (
        <>
            <GlobalHeader />

            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about-us" element={<AboutUs />} />
                <Route path="/contact-us" element={<ContactUs />} />
                <Route path="/customers" element={<Customers />} />
                <Route path="/sign-in" element={<SignInUp />} />
            </Routes>

            <GlobalFooter />
        </>
    );
};

export default Layout;