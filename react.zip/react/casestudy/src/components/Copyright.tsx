const Copyright = () => {
    return (
        <>
            <div className="col-md-6 widget">
                <div className="widget-body">
                    <p className="text-right">
                        Copyright &copy; 2014, Your name. Designed by <a href="http://gettemplate.com/" rel="designer">gettemplate</a>
                    </p>
                </div>
            </div>

        </>
    );
};

export default Copyright;