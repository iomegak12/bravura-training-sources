import ContactMap from "./ContactMap";
import ContactUsForm from "./ContactUsForm"
import Sidebar from "./Sidebar";

const ContactUs = () => {
    return (
        <>
            <header id="head" className="secondary"></header>

            <div className="container">

                <ol className="breadcrumb">
                    <li><a href="index.html">Home</a></li>
                    <li className="active">About</li>
                </ol>

                <div className="row">
                    <article className="col-sm-9 maincontent">
                        <header className="page-header">
                            <h1 className="page-title">Contact us</h1>
                        </header>

                        <p>
                            We’d love to hear from you. Interested in working together? Fill out the form below with some info about your project and I will get back to you as soon as I can. Please allow a couple days for me to respond.
                        </p>

                        <br />

                        <ContactUsForm />

                    </article>

                    <Sidebar />
                </div>
            </div>

            <ContactMap />
        </>
    );
};

export default ContactUs