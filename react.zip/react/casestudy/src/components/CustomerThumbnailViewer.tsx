import Customer from "../models/Customer";

const CustomerThumbnailViewer = (props: Customer) => {
    return (
        <>
            <div className="thumbnail">
                <img src={`https://picsum.photos/242/200?random=${props.id}`} height={200} width={242} alt="Customer Photo" />

                <div className="caption">
                    <h3>{props.customerName}</h3>

                    <p>
                        {props.summary}
                    </p>

                    <p>
                        <a href="#" className="btn btn-primary" role="button" data-toggle="modal" data-target={`#customer${props.id}`}>Details</a>
                        &nbsp;
                        <a href="#" className="btn btn-default" role="button">Orders</a>
                    </p>
                </div>
            </div>

            <div className="modal fade" id={`customer${props.id}`} tabIndex={-1} role="dialog" aria-labelledby="myModalLabel">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 className="modal-title" id="myModalLabel">Customer Details of {props.customerName}</h4>
                        </div>
                        <div className="modal-body">
                            <h3>{props.customerName}</h3>
                            <h4>{props.address}</h4>
                            <h5>{props.email}</h5>
                            <p>
                                {props.summary}
                            </p>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="button" className="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default CustomerThumbnailViewer;