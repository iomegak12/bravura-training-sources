import { Link } from "react-router-dom";

const Navigation = () => {
    return (
        <>
            <div className="navbar-collapse collapse">
                <ul className="nav navbar-nav pull-right">
                    <li className="active">
                        <Link to="/">Home</Link>
                    </li>
                    <li>
                        <Link to="/about-us">About Us</Link>
                    </li>

                    <li className="dropdown">
                        <Link to="/customers">Customers</Link>
                    </li>

                    <li>
                        <Link to="/contact-us">Contact Us</Link>
                    </li>
                    <li>
                        <Link to="/sign-in">
                            SIGN IN / SIGN UP
                        </Link>
                    </li>
                </ul>
            </div>
        </>
    );
};

export default Navigation;

