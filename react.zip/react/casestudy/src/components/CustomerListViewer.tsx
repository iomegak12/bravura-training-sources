import Customer from "../models/Customer";
import CustomerThumbnailViewer from "./CustomerThumbnailViewer";

const CustomerListViewer = (props: any) => {
    return (
        <>
            <div className="row">

                {
                    props.customers &&
                    props.customers.map((customer: Customer) => {
                        return (
                            <>
                                <div className="col-sm-6 col-md-4">
                                    <CustomerThumbnailViewer key={customer.id} {...customer} />
                                </div>
                            </>
                        );
                    })
                }
            </div>
        </>
    )
};

export default CustomerListViewer;