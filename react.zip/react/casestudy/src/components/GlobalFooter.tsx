import Copyright from "./Copyright";
import FollowMe from "./FollowMe";
import FooterContact from "./FooterContact";
import FooterNavigation from "./FooterNavigation";
import FooterSummary from "./FooterSummary";

const GlobalFooter = () => {
    return (
        <>
            <footer id="footer" className="top-space">
                <div className="footer1">
                    <div className="container">
                        <div className="row">
                            <FooterContact />
                            <FollowMe />
                            <FooterSummary />
                        </div>
                    </div>
                </div>

                <div className="footer2">
                    <div className="container">
                        <div className="row">

                            <FooterNavigation />

                            <Copyright />
                        </div>
                    </div>
                </div>
            </footer >
        </>
    );
};

export default GlobalFooter;