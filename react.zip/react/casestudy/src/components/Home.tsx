import FAQ from "./FAQ";
import Reasons from "./Reasons"
import Social from "./Social"

const Home = () => {
    return (
        <>
            <header id="head">
                <div className="container">
                    <div className="row">
                        <h1 className="lead">AWESOME, CUSTOMIZABLE, FREE</h1>
                        <p className="tagline">PROGRESSUS: free business bootstrap template by <a href="http://www.gettemplate.com/?utm_source=progressus&amp;utm_medium=template&amp;utm_campaign=progressus">GetTemplate</a></p>
                        <p><a className="btn btn-default btn-lg" role="button">MORE INFO</a> <a className="btn btn-action btn-lg" role="button">DOWNLOAD NOW</a></p>
                    </div>
                </div>
            </header>

            <div className="container text-center">
                <br /> <br />
                <h2 className="thin">The best place to tell people why they are here</h2>
                <p className="text-muted">
                    The difference between involvement and commitment is like an eggs-and-ham breakfast:<br />
                    the chicken was involved; the pig was committed.
                </p>
            </div>

            <br />
            
            <Reasons />
            <FAQ />
            <Social />
        </>
    );
};

export default Home;