import { useSelector } from "react-redux";
import { AppDispatch, RootState } from "../store/store";
import { useDispatch } from "react-redux";
import { useCallback, useEffect } from "react";
import CustomerService from "../services/CustomerService";
import ICustomerService from "../services/ICustomerService";
import { CustomersActions } from "../slices/CustomersSlice";
import CustomerListViewer from "./CustomerListViewer";

const Customers = () => {
    const { customers } = useSelector((state: RootState) => state.customers)
    const dispatcher: AppDispatch = useDispatch();

    useEffect(() => {
        const customerService: ICustomerService = new CustomerService();

        customerService
            .getCustomers()
            .then(customers => {
                dispatcher(CustomersActions.loadCustomers(customers));
            })
            .catch(error => {
                dispatcher(CustomersActions.loadCustomersFailed(error));
            });
    }, []);

    return (
        <>
            {
                customers &&
                (
                    <>
                        <header id="head" className="secondary"></header>

                        <div className="container">

                            <ol className="breadcrumb">
                                <li><a href="index.html">Home</a></li>
                                <li className="active">Customers</li>
                            </ol>

                            <br />

                            <CustomerListViewer customers={customers} />
                        </div>
                    </>
                )
            }

            {
                !customers &&
                (
                    <div>
                        No Customer Records Found!
                    </div>
                )
            }
        </>
    );
};

export default Customers;