class Customer {
    constructor(public id: number,
        public customerName: string, public address: string,
        public email: string, public credit: number, public activeStatus: boolean,
        public summary: string, public photoUrl: string
    ) { }
}

export default Customer;