class Order {
    constructor(public id: number, public orderDate: string,
        public billingAddress: string, public product: string, public quantity: number,
        public orderAmount: number, public orderStatus: boolean,
        public customerId: number) { }
}

export default Order;
