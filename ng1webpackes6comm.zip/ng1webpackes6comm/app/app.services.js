const UserService = function ($http, serviceUrls) {
    const userServiceUrl = `${serviceUrls.baseUserServiceUrl}/users.json`;

    return {
        list: function () {
            return $http.get(userServiceUrl, { cache: true })
                .then(response => response.data);
        }
    };
};

export default UserService;