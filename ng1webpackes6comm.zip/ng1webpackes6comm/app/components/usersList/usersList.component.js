import { filter } from 'angular-ui-router';

const usersList = {
    bindings: {
        users: '<'
    },
    templateUrl: require('./usersList.component.html'),
    controller: function () {
        this.processActivities = function () {
            alert("Processing Activities Completed ...");
        };

        console.log("JSON : " + JSON.stringify(this.users));

        this.toggleActive = function (userId) {
            let filteredUser = this.users.find(user => user.id === userId);

            if (filteredUser) {
                filteredUser.active = !filteredUser.active;
            }
        };
    }
};

export default usersList;