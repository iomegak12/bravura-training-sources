const home = {
    bindings: {},
    templateUrl: require('./home.component.html'),
    controller: function ($scope) {
        $scope.welcomeMessage = `Welcome Home`;
    }
};

export default home;