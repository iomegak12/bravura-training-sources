const userLink = {
    bindings: {
        user: '<',
        onToggleActive: '&'
    },
    templateUrl: require('./userLink.component.html')
};

export default userLink;