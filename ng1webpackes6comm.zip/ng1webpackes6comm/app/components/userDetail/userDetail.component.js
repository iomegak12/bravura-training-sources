const userDetail = {
    bindings: {
        user: "<",
    },
    templateUrl: require('./userDetail.component.html')
};

export default userDetail;