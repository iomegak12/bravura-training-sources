const defineStates = ($stateProvider, $locationProvider, $urlRouterProvider) => {
    $urlRouterProvider.otherwise("/home");
    $locationProvider.html5Mode(true);

    $stateProvider.state("home", {
        url: '/home',
        template: '<home></home>'
    });

    $stateProvider.state("userslist", {
        url: '/users',
        component: "usersList",
        resolve: {
            users: function (UserService) {
                return UserService.list();
            }
        }
    });

    $stateProvider.state("userslist.detail", {
        url: '/user-details/:userId',
        component: 'userDetail',
        resolve: {
            user: function ($transition$, users) {
                const userId = $transition$.params().userId;
                const filteredUser = users.find(user => user.id == userId);

                return filteredUser;
            }
        }
    });
};

export default defineStates;