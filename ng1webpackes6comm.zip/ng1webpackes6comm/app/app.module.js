import 'bootstrap/dist/css/bootstrap.min.css';

import angular from 'angular';
import uiRouter from 'angular-ui-router';
import ngSanitize from 'angular-sanitize';
import uiBootstrap from 'angular-ui-bootstrap';

import UserService from './app.services';
import serviceUrls from './app.constants';
import home from './components/home/home.component';
import defineStates from './app.states';
import appComponent from './components/app/app.component';
import usersList from './components/usersList/usersList.component';
import userLink from './components/userLink/userLink.component';
import userDetail from './components/userDetail/userDetail.component';

const MODULE_NAME = "casestudyApp";

angular
    .module(MODULE_NAME,
        [
            uiRouter,
            ngSanitize,
            uiBootstrap
        ])
    .factory("UserService", UserService)
    .constant('serviceUrls', serviceUrls)
    .component("mainApp", appComponent)
    .component("home", home)
    .component("usersList", usersList)
    .component("userLink", userLink)
    .component("userDetail", userDetail)
    .config(defineStates)
    .run(function ($http, serviceUrls) {
        $http.get(`${serviceUrls.baseUserServiceUrl}/users.json`, { cache: true });

        console.log("Application Initialized Successfully, with Caching!");
    });

require('../index.html');
require('../data/users.json');

export default MODULE_NAME;