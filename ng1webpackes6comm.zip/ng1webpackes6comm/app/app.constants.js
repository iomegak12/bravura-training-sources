const serviceUrls = {
    baseUserServiceUrl: '/data'
};

export default serviceUrls;