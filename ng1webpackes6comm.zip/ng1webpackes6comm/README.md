### Professional Angular 1.x - ES2015 and Webpack

