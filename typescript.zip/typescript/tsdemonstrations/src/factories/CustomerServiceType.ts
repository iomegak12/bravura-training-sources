export enum CustomerServiceType {
    Gold = "Gold",
    Silver = "Silver",
    Bronze = "Bronze",
    Online = "Online"
}
