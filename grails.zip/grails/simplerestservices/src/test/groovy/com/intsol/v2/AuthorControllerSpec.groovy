package com.intsol.v2

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AuthorControllerSpec extends Specification implements ControllerUnitTest<AuthorController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
        true == false
    }
}