package studentsweb

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
