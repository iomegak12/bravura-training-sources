package com.intsol

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class StudentControllerSpec extends Specification implements ControllerUnitTest<StudentController> {

    def setup() {
    }

    def cleanup() {
    }


}
