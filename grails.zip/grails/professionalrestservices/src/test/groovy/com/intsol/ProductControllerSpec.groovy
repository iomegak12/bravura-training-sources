package com.intsol

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class ProductControllerSpec extends Specification implements ControllerUnitTest<ProductController> {

    def setup() {
    }

    def cleanup() {
    }
}