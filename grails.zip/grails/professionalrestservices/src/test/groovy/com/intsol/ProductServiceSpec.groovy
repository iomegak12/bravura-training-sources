package com.intsol

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ProductServiceSpec extends Specification implements ServiceUnitTest<ProductService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
