package com.intsol

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
