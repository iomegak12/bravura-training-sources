package com.intsol

class Student {

    String firstName
    String lastName
    String course
    String summary

    static constraints = {
    }

}
