package com.example

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}